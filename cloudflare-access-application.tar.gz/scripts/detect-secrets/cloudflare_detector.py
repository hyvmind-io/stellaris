"""
Custom detect-secrets plugin for Cloudflare credentials.

Detects:
  - Cloudflare API Tokens (scoped tokens): 40-character alphanumeric strings
    in assignment context (CLOUDFLARE_API_TOKEN=, Bearer header, api_token =).
  - Cloudflare Global API Keys: 37-character hex strings in assignment context
    (CF_API_KEY=, X-Auth-Key header).

Does NOT detect (by design):
  - Cloudflare Account IDs (32-char hex) — not secrets.
  - Cloudflare Zone IDs (32-char hex) — not secrets.
  - CF_API_EMAIL — just an email address, not a secret.
  - Placeholder values like 'your-cloudflare-api-token-here'.

All patterns are context-aware: they require a recognizable keyword prefix
(variable name, header name, or 'Bearer') to avoid false positives on
arbitrary alphanumeric strings.
"""

import re

import requests

from detect_secrets.constants import VerifiedResult
from detect_secrets.plugins.base import RegexBasedDetector


class CloudflareDetector(RegexBasedDetector):
    """Scans for Cloudflare API Tokens and Global API Keys."""

    secret_type = "Cloudflare Credential"  # pragma: allowlist secret

    # Boundary after the captured secret: next char must NOT be a valid
    # token/key character, or we must be at end-of-string.
    _boundary = r"(?=[^A-Za-z0-9_-]|$)"

    denylist = [
        # ----------------------------------------------------------------
        # Cloudflare API Token (40-char alphanumeric, underscores, hyphens)
        # ----------------------------------------------------------------
        # Explicit env-var / config-key assignment
        # e.g. CLOUDFLARE_API_TOKEN="AbCd..."  |  export CF_API_TOKEN=AbCd...
        re.compile(
            r"(?:CLOUDFLARE_API_TOKEN|CLOUDFLARE_TOKEN|CF_API_TOKEN|CF_TOKEN)"
            r'\s*[=:]\s*["\']?'
            r"([A-Za-z0-9_-]{40})" + _boundary,
            flags=re.IGNORECASE,
        ),
        # Terraform / HCL / generic config style with cloudflare/cf prefix
        # e.g. cloudflare_api_token = "xxx"  |  cf.token: "xxx"
        re.compile(
            r"(?:cloudflare|cf)[_.-]?(?:api[_.-]?)?token"
            r'\s*[=:]\s*["\']?'
            r"([A-Za-z0-9_-]{40})" + _boundary,
            flags=re.IGNORECASE,
        ),
        # Bearer token in Authorization header
        # e.g. Authorization: Bearer AbCdEf...  |  -H "Bearer xxx"
        re.compile(
            r"Bearer\s+([A-Za-z0-9_-]{40})" + _boundary,
        ),
        # ----------------------------------------------------------------
        # Cloudflare Global API Key (37-char lowercase hex)
        # ----------------------------------------------------------------
        # Explicit env-var assignment
        # e.g. CF_API_KEY="abc123..."  |  export CLOUDFLARE_API_KEY=abc123...  # pragma: allowlist secret
        re.compile(
            r"(?:CF_API_KEY|CLOUDFLARE_API_KEY|CLOUDFLARE_GLOBAL_API_KEY)"
            r'\s*[=:]\s*["\']?'
            r"([0-9a-f]{37})" + _boundary,
            flags=re.IGNORECASE,
        ),
        # X-Auth-Key HTTP header
        # e.g. X-Auth-Key: abc123...  |  "X-Auth-Key": "abc123..."
        re.compile(
            r'X-Auth-Key["\']?\s*[:=]\s*["\']?'
            r"([0-9a-f]{37})" + _boundary,
            flags=re.IGNORECASE,
        ),
        # Config / code style with cloudflare/cf prefix + key keyword
        # e.g. cf_global_api_key = "xxx"  |  cloudflare_api_key: "xxx"  # pragma: allowlist secret
        re.compile(
            r"(?:cloudflare|cf)[_.-]?(?:global[_.-]?)?(?:api[_.-]?)?key"
            r'\s*[=:]\s*["\']?'
            r"([0-9a-f]{37})" + _boundary,
            flags=re.IGNORECASE,
        ),
    ]

    def verify(self, secret: str) -> VerifiedResult:  # pragma: no cover
        """Verify a detected secret against the Cloudflare API.

        Only API Tokens (40-char) can be verified via the token-verify
        endpoint.  Global API Keys (37-char hex) require an email address
        for authentication, so they are returned as UNVERIFIED.
        """
        # Global API Keys cannot be verified without the account email.
        if re.fullmatch(r"[0-9a-f]{37}", secret):
            return VerifiedResult.UNVERIFIED

        try:
            response = requests.get(
                "https://api.cloudflare.com/client/v4/user/tokens/verify",
                headers={
                    "Authorization": f"Bearer {secret}",
                    "Content-Type": "application/json",
                },
                timeout=5,
            )
        except requests.exceptions.RequestException:
            return VerifiedResult.UNVERIFIED

        if response.status_code == 200:
            try:
                data = response.json()
                if (
                    data.get("success")
                    and data.get("result", {}).get("status") == "active"
                ):
                    return VerifiedResult.VERIFIED_TRUE
            except ValueError:
                pass

        return VerifiedResult.VERIFIED_FALSE
