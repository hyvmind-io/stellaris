# AGENTS.md — cloudflare-access-application

## Repository Overview

OpenTofu/Terragrunt module for managing **Cloudflare Zero Trust Access Applications**.
Uses the Cloudflare provider `~> 5.11.0` and supports `self_hosted`, `SSH`, `VNC`, `RDP`,
`SaaS`, and `bookmark` application types via the
`cloudflare_zero_trust_access_application` resource.

## File Structure

```text
main.tf              # Primary resource: cloudflare_zero_trust_access_application (for_each on var.access_applications)
variables.tf         # Inputs: account_id (string, required), access_applications (map of objects, optional)
outputs.tf           # Outputs: applications (map with id/name/domain/type/aud), application_ids (map of key→id)
versions.tf          # Required provider: cloudflare/cloudflare ~> 5.11.0
README.md            # Module README — contains auto-generated terraform-docs section
CONTRIBUTING.md      # Full contributing guide
Makefile             # Development commands
mkdocs.yaml          # MkDocs site configuration
.pre-commit-config.yaml
.terraform-docs.yml
.tflint.hcl
.markdownlint.json
.secrets.baseline
.gitignore
docs/                # MkDocs documentation source (index.md, usage.md, api-reference.md, etc.)
scripts/
  detect-secrets/
    cloudflare_detector.py  # Custom detect-secrets plugin for Cloudflare API tokens/keys
```

## Build / Lint / Test Commands

There is no traditional build system. Use these commands for validation:

```bash
# Format
tofu fmt -recursive                        # Format all .tf files
tofu fmt *.hcl                             # Format .hcl files

# Lint & validate
tflint --config=.tflint.hcl                # Static analysis
tofu validate                              # Validate config (requires tofu init first)

# Documentation
terraform-docs markdown table .            # Regenerate README.md API docs
make docs-generate                         # Same via Makefile
make docs-serve                            # Preview MkDocs site locally
make docs-build                            # Build static MkDocs site

# Pre-commit (run ALL checks at once)
pre-commit run --all-files                 # Run every configured hook
pre-commit run terraform_fmt --all-files   # Run a single hook
pre-commit run terraform_tflint --all-files

# Markdown & YAML
markdownlint --config .markdownlint.json *.md
yamllint -d '{extends: default, rules: {line-length: {max: 120}}}' *.yaml

# Dependency check
make check-deps                            # Verify all tools are installed
```

## Code Style — HCL / OpenTofu

- **Formatting**: `tofu fmt` (2-space indentation, aligned `=` within blocks). Pre-commit enforces this.
- **Naming**: `snake_case` for ALL identifiers — resources, variables, outputs, locals.
- **Resource naming**: Use `this` when there is only one resource of a given type.
- **Iteration**: Use `for_each` on map variables, never `count`.
- **Variables**: Every variable MUST have `description` and `type`. Use `optional(type, default)` for object fields.
- **Outputs**: Every output MUST have `description`. Use structured maps with `for` expressions.
- **Null handling**: `try(each.value.field, default)` for optional fields.
- **Conditional attributes**: `contains()` + ternary for type-dependent attributes.
- **Comments**: `#` style. Explain _why_, not _what_.
- **Line length**: 120 characters max.
- **No unused declarations**: TFLint enforces no unused variables, outputs, or locals.

### File Organization

| File           | Contents                                               |
| -------------- | ------------------------------------------------------ |
| `main.tf`      | Resource definitions, locals                           |
| `variables.tf` | All input variables with descriptions, types, defaults |
| `outputs.tf`   | All output values with descriptions                    |
| `versions.tf`  | Required providers and version constraints             |

## TFLint Rules

Configured in `.tflint.hcl` with the `terraform` plugin (recommended preset):

- `terraform_naming_convention` — snake_case enforced
- `terraform_documented_outputs` — enabled
- `terraform_documented_variables` — enabled
- `terraform_typed_variables` — enabled
- `terraform_unused_declarations` — enabled
- `terraform_required_providers` — enabled
- `terraform_standard_module_structure` — enabled (must have main.tf, variables.tf, outputs.tf)
- `terraform_required_version` — **disabled**

## Pre-commit Hooks

| Hook                  | Purpose                        |
| --------------------- | ------------------------------ |
| `trailing-whitespace` | Remove trailing whitespace     |
| `end-of-file-fixer`   | Ensure files end with newline  |
| `check-yaml`          | Validate YAML syntax           |
| `terraform_fmt`       | Format `.tf` files (recursive) |
| `terraform_docs`      | Regenerate README.md API docs  |
| `terraform_tflint`    | Run TFLint static analysis     |
| `yamllint`            | Lint YAML (120 char line max)  |
| `markdownlint`        | Lint and auto-fix Markdown     |
| `detect-secrets`      | Scan for leaked credentials    |
| `hcl-fmt`             | Format `.hcl` files            |

When hooks auto-fix files, re-stage and re-commit the changes.

## Documentation

### README.md (terraform-docs)

The `README.md` contains an auto-generated section between these markers:

```html
<!-- BEGIN_TF_DOCS -->
...
<!-- END_TF_DOCS -->
```

**DO NOT manually edit content between these markers.**
It is regenerated by `terraform-docs` via pre-commit hooks or `make docs-generate`.

### MkDocs

Documentation source lives in `docs/`. Preview with `make docs-serve`. Configuration is in `mkdocs.yaml`.

## Version Control

- Uses **Jujutsu (jj)** with a Git backend.
- Pre-commit hooks must be installed: `pre-commit install` or `make pre-commit-install`.
- Commit messages should be clear and descriptive (e.g., "Add support for SaaS application type").

## Security

- **Never commit** API tokens, secrets, state files (`*.tfstate`), or `.env` files.
- `.secrets.baseline` is tracked (contains false-positive markers, not actual secrets).
- Custom Cloudflare detector in `scripts/detect-secrets/cloudflare_detector.py`
  flags API tokens (40-char alphanum) and Global API keys (37-char hex)
  but NOT Account/Zone IDs.

## Python (scripts/)

- Standard Python style with docstrings.
- Imports: stdlib first, then third-party, then local (`detect_secrets`).
- Uses `re` module and `RegexBasedDetector` base class.

## Critical Rules

1. **Always run `pre-commit run --all-files`** before committing.
2. **Never edit the terraform-docs section** in README.md manually.
3. **All variables and outputs** must have `description` and `type`.
4. **Use `for_each`** over `count` for resource iteration.
5. **Use `snake_case`** for all identifiers.
6. **No unused declarations** — TFLint will fail the check.
7. **Regenerate docs** (`make docs-generate`) after changing `.tf` files.
8. **120 character line limit** for HCL, Markdown, and YAML.
