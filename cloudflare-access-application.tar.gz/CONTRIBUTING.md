# Contributing to cloudflare-access-application

Thank you for your interest in contributing to this OpenTofu/Terragrunt module.
This guide covers everything you need to know to contribute effectively.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Development Setup](#development-setup)
- [Repository Structure](#repository-structure)
- [Development Workflow](#development-workflow)
- [Code Style and Formatting](#code-style-and-formatting)
- [Documentation](#documentation)
- [Pre-commit Hooks](#pre-commit-hooks)
- [MkDocs Documentation Site](#mkdocs-documentation-site)
- [Submitting Changes](#submitting-changes)
- [Code Review Guidelines](#code-review-guidelines)
- [Security](#security)

## Prerequisites

Install the following tools before contributing:

| Tool                                                                     | Install                          | Purpose                             |
| ------------------------------------------------------------------------ | -------------------------------- | ----------------------------------- |
| [OpenTofu](https://opentofu.org/)                                        | `brew install opentofu`          | Infrastructure-as-code engine       |
| [Terragrunt](https://terragrunt.gruntwork.io/)                           | `brew install terragrunt`        | OpenTofu wrapper and orchestrator   |
| [terraform-docs](https://terraform-docs.io/)                             | `brew install terraform-docs`    | Auto-generate module documentation  |
| [TFLint](https://github.com/terraform-linters/tflint)                    | `brew install tflint`            | OpenTofu linter and static analysis |
| [pre-commit](https://pre-commit.com/)                                    | `pip install pre-commit`         | Git hook manager for code quality   |
| [MkDocs](https://www.mkdocs.org/)                                        | `pip install mkdocs`             | Documentation site generator        |
| [pymdown-extensions](https://facelessuser.github.io/pymdown-extensions/) | `pip install pymdown-extensions` | MkDocs markdown extensions          |
| [jj](https://martinvonz.github.io/jj/)                                   | `brew install jj`                | Jujutsu version control system      |
| [gh](https://cli.github.com/)                                            | `brew install gh`                | GitHub CLI                          |

Verify your setup:

```bash
make check-deps
```

## Development Setup

```bash
# 1. Clone the repository
gh repo clone terragrunt-cloudflare-modules/cloudflare-access-application
cd cloudflare-access-application

# 2. Install pre-commit hooks
make pre-commit-install

# 3. Verify everything works
make check-deps
make pre-commit-run
```

## Repository Structure

```text
cloudflare-access-application/
├── main.tf                      # Primary resource definitions
├── variables.tf                 # Input variable declarations
├── outputs.tf                   # Output value declarations
├── versions.tf                  # Provider and version constraints
├── README.md                    # Module README (auto-generated section)
├── LICENSE                      # License file
├── CONTRIBUTING.md              # This file
├── Makefile                     # Development commands
├── mkdocs.yaml                  # MkDocs site configuration
├── .pre-commit-config.yaml      # Pre-commit hook definitions
├── .terraform-docs.yml          # terraform-docs configuration
├── .tflint.hcl                  # TFLint rules and plugins
├── .markdownlint.json           # Markdown linting rules
├── .secrets.baseline            # detect-secrets baseline
├── .gitignore                   # Git ignore rules
├── .description                 # GitHub repository description (gitignored)
├── docs/                        # MkDocs documentation source
│   ├── index.md                 # Home page
│   ├── usage.md                 # Usage guide and examples
│   ├── api-reference.md         # Auto-generated API reference
│   ├── contributing.md          # Contributing guide (for docs site)
│   └── development.md           # Development guide (for docs site)
└── scripts/
    └── detect-secrets/
        ├── __init__.py
        └── cloudflare_detector.py  # Custom Cloudflare secret detector
```

## Development Workflow

### 1. Create a Feature Branch

```bash
# Using jj (Jujutsu)
jj new -m "description of your change"
```

### 2. Make Your Changes

Edit the relevant `.tf` files. Follow the [Code Style](#code-style-and-formatting) guidelines.

### 3. Regenerate Documentation

```bash
# Regenerate terraform-docs in README.md
make docs-generate

# Rebuild the MkDocs site locally to preview
make docs-serve
```

### 4. Run All Quality Checks

```bash
# Run all pre-commit hooks
make pre-commit-run

# Or run specific checks
make fmt          # Format .tf files
make lint         # Run TFLint
make docs-check   # Verify docs are up to date
```

### 5. Commit and Push

```bash
jj describe -m "Add support for custom CORS headers"
jj bookmark set master
jj git push --bookmark master --remote origin
```

## Code Style and Formatting

### OpenTofu / HCL

- **Formatting**: All `.tf` files must be formatted with `tofu fmt`. The pre-commit hook does this automatically.
- **Naming convention**: Use `snake_case` for all resource names, variables, outputs, and locals.
- **Variables**: Every variable must have a `description` and a `type`.
- **Outputs**: Every output must have a `description`.
- **Resources**: Use `this` as the resource name when there is only one resource of that type:
  `resource "cloudflare_zero_trust_access_application" "this"`.
- **Iteration**: Use `for_each` for resource iteration from maps/objects.
- **Optional attributes**: Use `try(value, default)` for optional nested attributes.
- **Comments**: Explain _why_, not _what_. Code should be self-explanatory.

### File Organization

| File           | Contents                                                   |
| -------------- | ---------------------------------------------------------- |
| `main.tf`      | Resource definitions and locals                            |
| `variables.tf` | All input variables with descriptions, types, and defaults |
| `outputs.tf`   | All output values with descriptions                        |
| `versions.tf`  | Required providers and version constraints                 |

### Variable Definitions

```hcl
variable "example" {
  description = "Clear description of what this variable controls"
  type        = string
  default     = "sensible-default"
}
```

### Output Definitions

```hcl
output "example_ids" {
  description = "Map of example keys to their IDs"
  value = {
    for k, v in resource.this : k => v.id
  }
}
```

### What Reviewers Look For

- [ ] Variables have clear descriptions and appropriate types
- [ ] Outputs are documented and useful
- [ ] `try()` is used for optional nested attributes
- [ ] Resource names follow `snake_case` convention
- [ ] No hardcoded values that should be variables
- [ ] `for_each` is used instead of `count` where possible
- [ ] Comments explain complex logic or Cloudflare-specific behavior
- [ ] terraform-docs markers are present in README.md
- [ ] Pre-commit hooks pass cleanly

## Documentation

### terraform-docs (API Reference)

The `README.md` contains an auto-generated section between
`<!-- BEGIN_TF_DOCS -->` and `<!-- END_TF_DOCS -->` markers.
This is updated automatically by pre-commit hooks when you modify `.tf` files.

**Manual regeneration:**

```bash
# Regenerate README.md API docs
make docs-generate

# Verify docs are up to date (CI check)
make docs-check
```

**Configuration:** `.terraform-docs.yml` controls the output format.
Do not manually edit the content between the TF_DOCS markers — it will be overwritten.

### MkDocs (Documentation Site)

The `docs/` directory contains the source files for the MkDocs documentation site.

**Preview locally:**

```bash
# Start the development server (auto-reloads on changes)
make docs-serve
# → Opens at http://127.0.0.1:8000

# Build static site (outputs to site/)
make docs-build
```

**Updating documentation:**

1. Edit files in `docs/` directly
2. Preview with `make docs-serve`
3. Commit the changes (pre-commit will lint the markdown)

**Adding a new page:**

1. Create `docs/new-page.md`
2. Add it to the `nav` section in `mkdocs.yaml`
3. Preview with `make docs-serve`

## Pre-commit Hooks

Pre-commit hooks run automatically on every commit to enforce code quality.

### Installed Hooks

| Hook                      | What It Does                              |
| ------------------------- | ----------------------------------------- |
| `trailing-whitespace`     | Removes trailing whitespace               |
| `end-of-file-fixer`       | Ensures files end with newline            |
| `check-yaml`              | Validates YAML syntax                     |
| `check-json`              | Validates JSON syntax                     |
| `check-added-large-files` | Prevents files > 1MB                      |
| `check-merge-conflict`    | Detects merge conflict markers            |
| `detect-private-key`      | Detects private keys                      |
| `mixed-line-ending`       | Enforces LF line endings                  |
| `terraform_fmt`           | Formats `.tf` files with `tofu fmt`       |
| `terraform_docs`          | Regenerates README.md API docs            |
| `terraform_tflint`        | Runs TFLint static analysis               |
| `yamllint`                | Lints YAML files                          |
| `markdownlint`            | Lints and auto-fixes Markdown             |
| `detect-secrets`          | Scans for leaked credentials              |
| `hcl-fmt`                 | Formats `.hcl` files                      |
| `mkdocs-build`            | Validates MkDocs site builds successfully |

### Setup

```bash
# Install hooks (one-time)
make pre-commit-install

# Run all hooks manually
make pre-commit-run

# Update hooks to latest versions
make pre-commit-update
```

### When Hooks Auto-Fix Files

Some hooks (e.g., `terraform_fmt`, `markdownlint`) auto-fix issues. If this happens:

```bash
# Re-add the auto-fixed files
jj squash   # or: jj describe -m "your message"
```

### Skipping Hooks (Emergency Only)

```bash
# Skip all hooks
jj describe --no-verify -m "emergency fix"

# Skip specific hook
SKIP=terraform_tflint jj describe -m "WIP"
```

> **Warning:** Only skip hooks in emergencies. Always run `make pre-commit-run` before pushing.

## MkDocs Documentation Site

### Overview

This module uses [MkDocs](https://www.mkdocs.org/) to generate a documentation site from Markdown files in the `docs/` directory.

### Commands

| Command              | Description                                       |
| -------------------- | ------------------------------------------------- |
| `make docs-serve`    | Start local dev server at `http://127.0.0.1:8000` |
| `make docs-build`    | Build static site to `site/` directory            |
| `make docs-generate` | Regenerate terraform-docs in README.md            |
| `make docs-check`    | Verify terraform-docs are up to date              |

### Workflow

1. **Edit** files in `docs/`
2. **Preview** with `make docs-serve` (auto-reloads)
3. **Build** with `make docs-build` to verify production build
4. **Commit** — pre-commit will lint your Markdown and validate the MkDocs build

### Configuration

- `mkdocs.yaml` — Site name, navigation, extensions, plugins
- `.markdownlint.json` — Markdown lint rules (ATX headings, line length, etc.)

### Extensions Available

- **pymdownx.superfences** — Fenced code blocks with Mermaid diagram support
- **pymdownx.highlight** — Syntax highlighting
- **pymdownx.tabbed** — Tabbed content blocks
- **pymdownx.snippets** — Include content from other files
- **admonition** — Note/warning/tip callout boxes
- **toc** — Table of contents with permalink anchors

## Submitting Changes

### Before Submitting

1. **Run all checks**: `make pre-commit-run`
2. **Regenerate docs**: `make docs-generate`
3. **Build docs**: `make docs-build`
4. **Review your changes**: Ensure no unintended modifications

### Commit Messages

Use clear, descriptive commit messages:

```text
Add support for SaaS application type configuration
Fix session_duration default for bookmark applications
Update variable descriptions for clarity
docs: Add Terragrunt integration example
```

### Pull Request Guidelines

1. **Title**: Clear, concise description of the change
2. **Description**: Explain _what_ changed and _why_
3. **Testing**: Describe how you tested the change
4. **Documentation**: Confirm docs are regenerated if `.tf` files changed

## Code Review Guidelines

### What Reviewers Check

1. **Correctness**: Does the change work as described?
2. **Style**: Does it follow the coding conventions above?
3. **Documentation**: Are variables, outputs, and README updated?
4. **Security**: No hardcoded secrets or overly permissive defaults
5. **Backwards compatibility**: Does it break existing configurations?
6. **Testing**: Has the contributor tested with a real Cloudflare account?

### Common Feedback

- "Please add a description to this variable"
- "Use `try()` for this optional attribute"
- "This should be a variable, not hardcoded"
- "Please run `make docs-generate` — the README is out of date"
- "Please run `make pre-commit-run` — formatting issues"

## Security

### Never Commit

- API tokens or secrets
- State files (`*.tfstate`)
- Environment files (`.env`, `.secrets`)
- Private keys

### The `.secrets.baseline` File

The `.secrets.baseline` file IS tracked in version control.
It's used by the `detect-secrets` pre-commit hook to track known false positives.
It does not contain actual secrets.

### Custom Cloudflare Detector

The `scripts/detect-secrets/cloudflare_detector.py` plugin detects:

- Cloudflare API Tokens (40-char alphanumeric)
- Cloudflare Global API Keys (37-char hex)

It does NOT flag Account IDs or Zone IDs (those are not secrets).

## Resources

- [Cloudflare Zero Trust Access Application](https://registry.terraform.io/providers/cloudflare/cloudflare/latest/docs/resources/zero_trust_access_application)
- [OpenTofu Documentation](https://opentofu.org/docs/)
- [Terragrunt Documentation](https://terragrunt.gruntwork.io/docs/)
- [Terraform Best Practices](https://www.terraform-best-practices.com/)
- [Pre-commit Documentation](https://pre-commit.com/)
- [MkDocs Documentation](https://www.mkdocs.org/)
- [terraform-docs](https://terraform-docs.io/)
