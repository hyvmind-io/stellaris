# cloudflare-access-application

OpenTofu/Terragrunt module for managing Cloudflare Zero Trust Access Applications
with support for self-hosted, SSH, VNC, RDP, SaaS, and bookmark application types.

## Overview

This module manages `cloudflare_zero_trust_access_application` resources,
allowing you to define and configure Zero Trust Access Applications
for your Cloudflare account.

## Quick Start

```hcl
module "access_apps" {
  source = "github.com/terragrunt-cloudflare-modules/cloudflare-access-application"

  account_id = var.account_id

  access_applications = {
    my_app = {
      name   = "My Internal App"
      domain = "app.example.com"
      type   = "self_hosted"
    }
  }
}
```

## Requirements

- OpenTofu >= 1.0 or Terraform >= 1.0
- Cloudflare provider ~> 5.11.0
- A Cloudflare account with Zero Trust enabled
