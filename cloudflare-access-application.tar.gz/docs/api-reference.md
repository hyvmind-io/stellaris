# API Reference

Auto-generated documentation from Terraform source files.

<!-- BEGIN_TF_DOCS -->
<!-- END_TF_DOCS -->

For the full Cloudflare provider documentation, see:
[cloudflare_zero_trust_access_application](https://registry.terraform.io/providers/cloudflare/cloudflare/latest/docs/resources/zero_trust_access_application)
