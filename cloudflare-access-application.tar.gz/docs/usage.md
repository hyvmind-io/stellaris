# Usage

## Basic Configuration

Define access applications using the `access_applications` variable:

```hcl
access_applications = {
  internal_dashboard = {
    name                      = "Internal Dashboard"
    domain                    = "dashboard.example.com"
    type                      = "self_hosted"
    session_duration          = "24h"
    auto_redirect_to_identity = true
    allowed_idps              = ["<your-idp-id>"]
  }
}
```

## Application Types

The module supports the following application types:

| Type          | Description                                   |
| ------------- | --------------------------------------------- |
| `self_hosted` | Web application hosted on your infrastructure |
| `ssh`         | SSH access via browser                        |
| `vnc`         | VNC access via browser                        |
| `rdp`         | RDP access via browser                        |
| `saas`        | SaaS application integration                  |
| `bookmark`    | Bookmark link in the App Launcher             |

## Terragrunt Integration

### Inline inputs

```hcl
# terragrunt.hcl
terraform {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=master"
}

inputs = {
  account_id = dependency.account.outputs.account_id

  access_applications = {
    internal_dashboard = {
      name   = "Internal Dashboard"
      domain = "dashboard.example.com"
      type   = "self_hosted"
    }
  }
}
```

### YAML-driven configuration (recommended)

Separate data from logic by defining applications in a YAML file.
This lets non-Terraform users manage applications by editing YAML only.

`apps.yaml`:

```yaml
# Each top-level key becomes the resource identifier.
# Only 'name' is required — all other fields are optional.

internal_dashboard:
  name: "Internal Dashboard"
  domain: "dashboard.example.com"
  type: "self_hosted"
  session_duration: "8h"
  auto_redirect_to_identity: false
  app_launcher_visible: true

ssh_bastion:
  name: "SSH Bastion"
  type: "ssh"
  session_duration: "4h"

grafana_bookmark:
  name: "Grafana"
  domain: "grafana.example.com"
  type: "bookmark"
  app_launcher_visible: true
```

`terragrunt.hcl`:

```hcl
terraform {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=master"
}

inputs = {
  account_id = dependency.account.outputs.account_id

  # Load application definitions from YAML
  access_applications = yamldecode(file("apps.yaml"))
}
```

### Using dependencies

Pull `account_id` from another Terragrunt module instead of hardcoding:

```hcl
dependency "account" {
  config_path = "../cloudflare-account"
}

terraform {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=master"
}

inputs = {
  account_id          = dependency.account.outputs.account_id
  access_applications = yamldecode(file("apps.yaml"))
}
```

### Multiple environments

Use the same YAML schema across environments with different files:

```text
environments/
├── production/
│   ├── terragrunt.hcl
│   └── apps.yaml          # Production applications
├── staging/
│   ├── terragrunt.hcl
│   └── apps.yaml          # Staging applications
└── development/
    ├── terragrunt.hcl
    └── apps.yaml           # Development applications
```

Each `terragrunt.hcl` is identical — only `apps.yaml` differs per environment.
