# Upgrade from v0.x to v1.x

Please consult the `examples` directory for reference example configurations.
If you find a bug, please open an issue with supporting configuration to reproduce.

## List of backwards incompatible changes

- Initial release — no backwards incompatible changes yet.

## Additional changes

### Added

- Cloudflare Zero Trust Access Application management via `cloudflare_zero_trust_access_application`
- Support for `self_hosted`, `ssh`, `vnc`, `rdp`, `saas`, and `bookmark` application types
- `for_each` iteration via map variable `access_applications`

### Modified

- N/A (initial release)

### Variable and output changes

1. Removed variables:
   - N/A

2. Renamed variables:
   - N/A

3. Added variables:
   - `account_id` — Cloudflare account ID (required)
   - `access_applications` — Map of access application configurations

4. Removed outputs:
   - N/A

5. Renamed outputs:
   - N/A

6. Added outputs:
   - `applications` — Map of created access applications and their attributes
   - `application_ids` — Map of application keys to IDs
