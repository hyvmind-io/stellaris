# Development Guide

This guide covers the development toolchain, documentation workflows, and quality gates for this module.

## Tool Requirements

| Tool           | Install                                 | Version Check              |
| -------------- | --------------------------------------- | -------------------------- |
| OpenTofu       | `brew install opentofu`                 | `tofu version`             |
| Terragrunt     | `brew install terragrunt`               | `terragrunt --version`     |
| terraform-docs | `brew install terraform-docs`           | `terraform-docs --version` |
| TFLint         | `brew install tflint`                   | `tflint --version`         |
| pre-commit     | `pip install pre-commit`                | `pre-commit --version`     |
| MkDocs         | `pip install mkdocs pymdown-extensions` | `mkdocs --version`         |
| jj (Jujutsu)   | `brew install jj`                       | `jj --version`             |

Run `make check-deps` to verify all tools are installed.

## Quick Reference

```bash
make help               # Show all available commands
make fmt                # Format .tf files
make lint               # Run TFLint
make docs-generate      # Regenerate terraform-docs in README.md
make docs-serve         # Start MkDocs dev server
make docs-build         # Build MkDocs static site
make pre-commit-run     # Run all quality checks
make clean              # Remove generated files
```

## Documentation Workflows

### Regenerating API Documentation (terraform-docs)

The `README.md` file contains an auto-generated API reference section between markers:

```markdown
<!-- BEGIN_TF_DOCS -->

(auto-generated content)

<!-- END_TF_DOCS -->
```

**When to regenerate:**

- After modifying `main.tf`, `variables.tf`, or `outputs.tf`
- The pre-commit hook does this automatically on commit
- You can also run it manually:

```bash
make docs-generate
```

**Verify docs are current:**

```bash
make docs-check
```

This exits non-zero if the README is out of date — useful for CI.

### Working with MkDocs

#### Starting the Development Server

```bash
make docs-serve
```

This starts a local server at `http://127.0.0.1:8000` with **live reload** —
any change to files in `docs/` or `mkdocs.yaml` is reflected immediately.

#### Building the Static Site

```bash
make docs-build
```

Outputs to the `site/` directory (gitignored). The `--strict` flag ensures warnings are treated as errors.

#### Adding a New Documentation Page

1. Create the Markdown file in `docs/`:

   ```bash
   touch docs/my-new-page.md
   ```

2. Add it to the navigation in `mkdocs.yaml`:

   ```yaml
   nav:
     - Home: index.md
     - Usage: usage.md
     - API Reference: api-reference.md
     - My New Page: my-new-page.md
     - Development: development.md
     - Contributing: contributing.md
   ```

3. Preview with `make docs-serve`
4. Commit

#### MkDocs Extensions

This site has the following Markdown extensions available:

**Admonitions** (callout boxes):

```markdown
!!! note "Title"
Content of the note.

!!! warning
This is a warning without a custom title.

!!! tip "Pro Tip"
Useful information here.
```

**Fenced code blocks** with syntax highlighting:

````markdown
```hcl
resource "cloudflare_zero_trust_access_application" "this" {
  name = "example"
}
```
````

**Mermaid diagrams**:

````markdown
```mermaid
graph LR
    A[Terragrunt] --> B[Module]
    B --> C[Cloudflare API]
```
````

**Tabbed content**:

````markdown
=== "OpenTofu"

    ```bash
    tofu plan
    ```

=== "Terraform"

    ```bash
    terraform plan
    ```
````

### Updating the Documentation Site Configuration

Edit `mkdocs.yaml` to change:

- **`site_name`**: The site title
- **`nav`**: Navigation structure and page ordering
- **`markdown_extensions`**: Available Markdown features
- **`plugins`**: MkDocs plugins (currently: search)

## Pre-commit Hooks

### How Hooks Work

When you commit (via `jj describe` or `git commit`), pre-commit runs these hooks automatically:

1. **File integrity**: trailing whitespace, line endings, large files, merge conflicts
2. **OpenTofu**: `tofu fmt`, terraform-docs generation, TFLint
3. **YAML**: syntax validation and linting
4. **Markdown**: linting with auto-fix
5. **Security**: secret detection (Cloudflare tokens, API keys)
6. **HCL**: formatting
7. **MkDocs**: validates the documentation site builds

### Installing Hooks

```bash
make pre-commit-install
```

This installs the hooks into the `.git/hooks/` directory. They run automatically on every commit.

### Running Hooks Manually

```bash
# All hooks, all files
make pre-commit-run

# Specific hook
pre-commit run terraform_fmt --all-files
pre-commit run terraform_docs --all-files
pre-commit run mkdocs-build --all-files

# On specific files
pre-commit run --files main.tf variables.tf
```

### Updating Hook Versions

```bash
make pre-commit-update
```

This runs `pre-commit autoupdate` to pull the latest versions of all hooks.

### Hooks That Auto-Fix Files

These hooks modify files in-place when they find issues:

| Hook                  | What It Fixes                 |
| --------------------- | ----------------------------- |
| `terraform_fmt`       | Reformats `.tf` files         |
| `terraform_docs`      | Updates README.md API section |
| `markdownlint`        | Fixes Markdown formatting     |
| `trailing-whitespace` | Removes trailing whitespace   |
| `end-of-file-fixer`   | Adds missing final newline    |
| `mixed-line-ending`   | Converts to LF                |

When hooks auto-fix, the commit is aborted. Simply re-stage and commit again:

```bash
jj squash   # absorb the auto-fixed changes
```

## Formatting Rules

### OpenTofu / HCL

- Run `tofu fmt -recursive .` (or `make fmt`)
- 2-space indentation (enforced by `tofu fmt`)
- Align `=` in attribute blocks
- One blank line between resource blocks

### Markdown

Rules are defined in `.markdownlint.json`:

| Rule          | Setting                             |
| ------------- | ----------------------------------- |
| Heading style | ATX (`# Heading`)                   |
| List marker   | Dash (`-`)                          |
| Indentation   | 2 spaces                            |
| Line length   | 120 characters (code blocks exempt) |
| Inline HTML   | Allowed (for terraform-docs output) |
| Bare URLs     | Allowed                             |

### YAML

Rules are inline in `.pre-commit-config.yaml`:

- 2-space indentation
- Max 120 character line length
- No document start markers required (`---`)
- Comments need 1 space after `#`

## TFLint Rules

Configuration in `.tflint.hcl`:

| Rule                                  | Description                              |
| ------------------------------------- | ---------------------------------------- |
| `terraform_naming_convention`         | Enforces `snake_case`                    |
| `terraform_documented_outputs`        | All outputs must have descriptions       |
| `terraform_documented_variables`      | All variables must have descriptions     |
| `terraform_typed_variables`           | All variables must have type constraints |
| `terraform_unused_declarations`       | Flags unused variables and locals        |
| `terraform_required_providers`        | Requires provider version constraints    |
| `terraform_standard_module_structure` | Enforces standard file layout            |

## Secret Detection

The `detect-secrets` hook scans for accidentally committed credentials:

- **Cloudflare API Tokens**: 40-char alphanumeric strings in assignment context
- **Cloudflare Global API Keys**: 37-char hex strings in assignment context
- **General secrets**: AWS keys, private keys, JWT tokens, etc.

If a false positive is detected, update the baseline:

```bash
detect-secrets scan --baseline .secrets.baseline --plugin scripts/detect-secrets/cloudflare_detector.py
```
