# Contributing

For the full contributing guide, see
[CONTRIBUTING.md](https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application/blob/master/CONTRIBUTING.md)
in the repository root.

## Quick Start

```bash
# Clone and set up
gh repo clone terragrunt-cloudflare-modules/cloudflare-access-application
cd cloudflare-access-application

# Install pre-commit hooks
make pre-commit-install

# Verify setup
make check-deps
```

## Development Cycle

1. Make changes to `.tf` files
2. Run `make fmt` to format
3. Run `make docs-generate` to update API docs
4. Run `make pre-commit-run` to validate everything
5. Commit and push

## Key Commands

| Command               | Purpose                          |
| --------------------- | -------------------------------- |
| `make fmt`            | Format OpenTofu files            |
| `make lint`           | Run TFLint analysis              |
| `make docs-generate`  | Regenerate API docs in README.md |
| `make docs-serve`     | Preview documentation site       |
| `make docs-build`     | Build documentation site         |
| `make pre-commit-run` | Run all quality checks           |
| `make clean`          | Remove generated files           |

## What Reviewers Look For

- Variables have descriptions and types
- Outputs have descriptions
- `try()` used for optional attributes
- `snake_case` naming throughout
- No hardcoded secrets or IDs
- Documentation is regenerated
- Pre-commit hooks pass
