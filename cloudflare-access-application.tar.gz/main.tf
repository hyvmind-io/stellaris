locals {
  # Determine which types support which attributes
  # Based on Cloudflare provider documentation for v5.11.0
  app_types_with_launcher     = ["self_hosted", "ssh", "vnc", "rdp", "saas", "bookmark"]
  app_types_with_cookie_attrs = ["self_hosted", "ssh", "vnc", "rdp"]
}

resource "cloudflare_zero_trust_access_application" "this" {
  for_each = var.access_applications

  account_id                  = var.account_id
  name                        = each.value.name
  domain                      = try(each.value.domain, null)
  type                        = try(each.value.type, "self_hosted")
  session_duration            = try(each.value.session_duration, "24h")
  auto_redirect_to_identity   = try(each.value.auto_redirect_to_identity, false)
  allowed_idps                = try(each.value.allowed_idps, [])
  allow_authenticate_via_warp = try(each.value.allow_authenticate_via_warp, null)

  # Attributes only valid for certain types
  app_launcher_visible       = contains(local.app_types_with_launcher, try(each.value.type, "self_hosted")) ? try(each.value.app_launcher_visible, true) : null
  enable_binding_cookie      = contains(local.app_types_with_cookie_attrs, try(each.value.type, "self_hosted")) ? try(each.value.enable_binding_cookie, false) : null
  http_only_cookie_attribute = contains(local.app_types_with_cookie_attrs, try(each.value.type, "self_hosted")) ? try(each.value.http_only_cookie_attribute, true) : null
  options_preflight_bypass   = contains(local.app_types_with_cookie_attrs, try(each.value.type, "self_hosted")) ? try(each.value.options_preflight_bypass, false) : null
  self_hosted_domains        = contains(local.app_types_with_cookie_attrs, try(each.value.type, "self_hosted")) ? try(each.value.self_hosted_domains, null) : null

  # Note: Policies are managed separately in the access-policies component
  # No need to reference them here as they contain application_id references
}
