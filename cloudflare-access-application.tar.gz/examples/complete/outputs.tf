output "application_ids" {
  description = "Map of application keys to Cloudflare application IDs"
  value       = module.access_applications.application_ids
}

output "applications" {
  description = "Full map of created access applications and their attributes"
  value       = module.access_applications.applications
}
