################################################################################
# Cloudflare Access Application — Complete Example
################################################################################

provider "cloudflare" {
  # api_token set via CLOUDFLARE_API_TOKEN environment variable
}

locals {
  account_id = var.account_id
}

################################################################################
# Complete: multiple application types
################################################################################

module "access_applications" {
  source = "../.."

  account_id = local.account_id

  access_applications = {
    # Self-hosted web application
    internal_dashboard = {
      name                      = "Internal Dashboard"
      domain                    = "dashboard.example.com"
      type                      = "self_hosted"
      session_duration          = "8h"
      auto_redirect_to_identity = false
      app_launcher_visible      = true
      allowed_idps              = []
    }

    # SSH application (browser-rendered terminal)
    ssh_bastion = {
      name             = "SSH Bastion"
      type             = "ssh"
      session_duration = "4h"
    }

    # App Launcher bookmark (no authentication proxy)
    bookmark_grafana = {
      name                 = "Grafana (Bookmark)"
      domain               = "grafana.example.com"
      type                 = "bookmark"
      app_launcher_visible = true
    }
  }
}
