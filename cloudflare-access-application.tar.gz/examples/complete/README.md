# Complete Cloudflare Access Application Example

Configuration in this directory creates:

- A self-hosted web application (`internal_dashboard`)
- An SSH browser-rendered terminal application (`ssh_bastion`)
- An App Launcher bookmark (`bookmark_grafana`)

This example demonstrates the key application types and common configuration
patterns supported by the module.

## Usage

To run this example you need to execute:

```bash
export CLOUDFLARE_API_TOKEN="your-api-token"

tofu init
tofu plan -var="account_id=your-account-id"
tofu apply -var="account_id=your-account-id"
```

Note that this example creates real Cloudflare resources. Run `tofu destroy` when
you no longer need these resources.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_cloudflare"></a> [cloudflare](#requirement\_cloudflare) | ~> 5.11.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_access_applications"></a> [access\_applications](#module\_access\_applications) | ../.. | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_id"></a> [account\_id](#input\_account\_id) | Cloudflare account ID | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_application_ids"></a> [application\_ids](#output\_application\_ids) | Map of application keys to Cloudflare application IDs |
| <a name="output_applications"></a> [applications](#output\_applications) | Full map of created access applications and their attributes |
<!-- END_TF_DOCS -->

## License

Apache-2.0 Licensed. See [LICENSE](../../LICENSE).
