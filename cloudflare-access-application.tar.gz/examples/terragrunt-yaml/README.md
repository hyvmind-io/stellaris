# Terragrunt with YAML Configuration Example

This example demonstrates the recommended production pattern: define access
application configuration in a YAML file and load it via Terragrunt's
`yamldecode(file(...))`.

This separates **what** (YAML data) from **how** (HCL module logic), making
it easy for non-Terraform users to manage access applications by editing YAML.

## Directory Structure

```text
├── terragrunt.hcl    # Terragrunt configuration (sources the module)
└── apps.yaml         # Access application definitions (data only)
```

## Usage

```bash
export CLOUDFLARE_API_TOKEN="your-api-token"

terragrunt plan
terragrunt apply
```

## How It Works

1. `apps.yaml` defines access applications as a YAML map
2. `terragrunt.hcl` reads the YAML with `yamldecode(file(...))`
3. The parsed map is passed directly to `var.access_applications`
4. The module creates one `cloudflare_zero_trust_access_application`
   per entry in the map

## Adding a New Application

Simply add a new entry to `apps.yaml`:

```yaml
my_new_app:
  name: "My New App"
  domain: "newapp.example.com"
  type: "self_hosted"
```

Then run `terragrunt apply` — no HCL changes needed.
