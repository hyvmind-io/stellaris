# Terragrunt configuration for Cloudflare Access Applications
#
# Application definitions live in apps.yaml — edit that file
# to add, modify, or remove applications. No HCL changes needed.

terraform {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=master"
}

inputs = {
  account_id = "your-cloudflare-account-id"

  # Load application definitions from YAML
  access_applications = yamldecode(file("apps.yaml"))
}
