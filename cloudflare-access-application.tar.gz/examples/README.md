# Examples

The examples provided serve two primary purposes:

1. Show users working examples of the various ways the module can be configured
2. A means of testing/validating module changes

Please consult the
[Cloudflare Zero Trust documentation](https://developers.cloudflare.com/cloudflare-one/)
for best practices and usage recommendations.

## Available Examples

| Example                              | Description                                                    |
| ------------------------------------ | -------------------------------------------------------------- |
| [complete](./complete)               | OpenTofu/Terraform module call with multiple application types |
| [terragrunt-yaml](./terragrunt-yaml) | Production pattern: YAML config file + Terragrunt              |
