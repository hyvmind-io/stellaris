# cloudflare-access-application

Terraform/OpenTofu module for managing [Cloudflare Zero Trust Access Applications](https://developers.cloudflare.com/cloudflare-one/applications/).
Supports `self_hosted`, `ssh`, `vnc`, `rdp`, `saas`, and `bookmark` application types via
`cloudflare_zero_trust_access_application`.

## Usage

See [`examples`](./examples) directory for working configurations to reference:

```hcl
module "access_applications" {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=v1.0.0"

  account_id = "your-cloudflare-account-id"

  access_applications = {
    internal_dashboard = {
      name                      = "Internal Dashboard"
      domain                    = "dashboard.example.com"
      type                      = "self_hosted"
      session_duration          = "8h"
      auto_redirect_to_identity = false
      app_launcher_visible      = true
    }

    ssh_bastion = {
      name = "SSH Bastion"
      type = "ssh"
    }
  }
}
```

### Terragrunt usage

```hcl
# terragrunt.hcl
terraform {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=v1.0.0"
}

inputs = {
  account_id = "your-cloudflare-account-id"

  access_applications = {
    internal_dashboard = {
      name   = "Internal Dashboard"
      domain = "dashboard.example.com"
      type   = "self_hosted"
    }
  }
}
```

### YAML-driven configuration (recommended for production)

Separate data from logic by defining applications in a YAML file:

`apps.yaml`:

```yaml
internal_dashboard:
  name: "Internal Dashboard"
  domain: "dashboard.example.com"
  type: "self_hosted"
  session_duration: "8h"

ssh_bastion:
  name: "SSH Bastion"
  type: "ssh"
```

`terragrunt.hcl`:

```hcl
terraform {
  source = "git::https://github.com/terragrunt-cloudflare-modules/cloudflare-access-application.git?ref=v1.0.0"
}

inputs = {
  account_id = "your-cloudflare-account-id"

  access_applications = yamldecode(file("apps.yaml"))
}
```

This pattern lets non-Terraform users manage applications by editing
YAML — no HCL knowledge required.

## Examples

| Example                                       | Description                                                    |
| --------------------------------------------- | -------------------------------------------------------------- |
| [complete](./examples/complete)               | OpenTofu/Terraform module call with multiple application types |
| [terragrunt-yaml](./examples/terragrunt-yaml) | Production pattern: YAML config + Terragrunt                   |

<!-- BEGIN_TF_DOCS -->

## Requirements

| Name                                                                        | Version   |
| --------------------------------------------------------------------------- | --------- |
| <a name="requirement_cloudflare"></a> [cloudflare](#requirement_cloudflare) | ~> 5.11.0 |

## Providers

| Name                                                                  | Version |
| --------------------------------------------------------------------- | ------- |
| <a name="provider_cloudflare"></a> [cloudflare](#provider_cloudflare) | 5.11.0  |

## Modules

No modules.

## Resources

| Name                                                                                                                                                               | Type     |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------- |
| [cloudflare_zero_trust_access_application.this](https://registry.terraform.io/providers/cloudflare/cloudflare/latest/docs/resources/zero_trust_access_application) | resource |

## Inputs

| Name                                                                                       | Description                          | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Default | Required |
| ------------------------------------------------------------------------------------------ | ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------- | :------: |
| <a name="input_access_applications"></a> [access_applications](#input_access_applications) | Map of access applications to create | <pre>map(object({<br/> \_id = optional(string)<br/> name = string<br/> domain = optional(string)<br/> type = optional(string, "self_hosted")<br/> session_duration = optional(string, "24h")<br/> auto_redirect_to_identity = optional(bool)<br/> app_launcher_visible = optional(bool)<br/> allowed_idps = optional(list(string), [])<br/> self_hosted_domains = optional(list(string), [])<br/> enable_binding_cookie = optional(bool)<br/> http_only_cookie_attribute = optional(bool)<br/> options_preflight_bypass = optional(bool)<br/> allow_authenticate_via_warp = optional(bool)<br/> }))</pre> | `{}`    |    no    |
| <a name="input_account_id"></a> [account_id](#input_account_id)                            | Cloudflare account ID                | `string`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | n/a     |   yes    |

## Outputs

| Name                                                                             | Description                    |
| -------------------------------------------------------------------------------- | ------------------------------ |
| <a name="output_application_ids"></a> [application_ids](#output_application_ids) | Map of application keys to IDs |
| <a name="output_applications"></a> [applications](#output_applications)          | Created access applications    |

<!-- END_TF_DOCS -->

## License

GPL-3.0 Licensed. See [LICENSE](./LICENSE).
