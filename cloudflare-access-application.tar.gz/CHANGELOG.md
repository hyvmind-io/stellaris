# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- `cloudflare_zero_trust_access_application` resource with `for_each` iteration
- Support for `self_hosted`, `ssh`, `vnc`, `rdp`, `saas`, and `bookmark` application types
- Type-conditional attributes (cookie attributes only for applicable types)
- Input variables: `account_id` (required), `access_applications` (map of objects with optional fields)
- Outputs: `applications` (structured map with id/name/domain/type/aud), `application_ids` (key→id map)
- Cloudflare provider constraint `~> 5.11.0`
- OpenTofu required version constraint `>= 1.5.7` in `versions.tf`
- Complete examples (`examples/complete`, `examples/terragrunt-yaml`)
- GitHub Actions CI workflows (pre-commit, release, PR title validation, stale issues, lock threads)
- Pre-commit hooks (terraform_fmt, terraform_docs, tflint, markdownlint, yamllint, detect-secrets)
- MkDocs documentation site with usage guide, API reference, contributing, and development guides
- TFLint configuration with terraform plugin (recommended preset) and `terraform_required_version` rule
- Custom detect-secrets plugin for Cloudflare API tokens and Global API keys
- CONTRIBUTING.md with full development guide
- Makefile with development commands (fmt, lint, docs-generate, docs-serve, etc.)
- Disk-space cleanup step in pre-commit CI workflow
- Fork guard in release CI workflow

### Changed

- Bumped GitHub Actions to latest major versions (checkout v6, setup-node v6, stale v10,
  lock-threads v6, semantic-pull-request v6.1.1, semantic-release-action v6)
- Node.js 22 → 24 in release workflow
- License reference updated to GPL-3.0 in README
