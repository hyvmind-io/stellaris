output "applications" {
  value = {
    for k, v in cloudflare_zero_trust_access_application.this : k => {
      id     = v.id
      name   = v.name
      domain = v.domain
      type   = v.type
      aud    = v.aud
    }
  }
  description = "Created access applications"
}

output "application_ids" {
  value = {
    for k, v in cloudflare_zero_trust_access_application.this : k => v.id
  }
  description = "Map of application keys to IDs"
}
