variable "account_id" {
  description = "Cloudflare account ID"
  type        = string
}

variable "access_applications" {
  description = "Map of access applications to create"
  type = map(object({
    _id                         = optional(string)
    name                        = string
    domain                      = optional(string)
    type                        = optional(string, "self_hosted")
    session_duration            = optional(string, "24h")
    auto_redirect_to_identity   = optional(bool)
    app_launcher_visible        = optional(bool)
    allowed_idps                = optional(list(string), [])
    self_hosted_domains         = optional(list(string), [])
    enable_binding_cookie       = optional(bool)
    http_only_cookie_attribute  = optional(bool)
    options_preflight_bypass    = optional(bool)
    allow_authenticate_via_warp = optional(bool)
  }))
  default = {}
}
